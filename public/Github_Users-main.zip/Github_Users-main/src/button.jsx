export default function Button({color, value, number }) {
  return <button style={{background: color}}
  
  className="enter2">{value}{number} </button>;
}
