import React from "react";

export default function Para(){
    return (
        <>
        <p className="heading">Enter Username to Get Info</p>
        </>
    );
}